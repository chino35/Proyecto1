import UIKit

var numeros = 0...100

for numero in numeros {

    if (numero % 5) == 0{
    print ("\(numero)" , "Bingo")
    } else if (numero % 2) == 0{
    print ("\(numero)" , "par")
    } else if (numero % 2) != 0{
    print ("\(numero)" , "impar")
    } else if numero > 29 &&  numero < 41{
    print ("\(numero)" , "Viva Swift!!!")
    }
}
    
    
    
  

